export const BaseUrl='https://wpadmin.bill365.app/'

// export const auth_key='c299cf0ae55db8193eb2d3116'