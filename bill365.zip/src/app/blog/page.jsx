import { BentoGridThirdDemo } from '@/component/BlogList'
import React from 'react'

function Blog() {
  return (
    <>
    <div className="container mx-auto px-4">
    <div class="grid grid-cols-3 gap-4 py-10">

    <div class="col-span-2 px-4">
      <BentoGridThirdDemo />
    </div>
    <div class="px-4">05</div>
    </div>
    </div>
    </>
  )
}

export default Blog